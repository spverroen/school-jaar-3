<?php

require_once "./controller/productsController.php";

$productsController = new productsController();
$productsController->Handler();


?>